package estanteriadelibros;

import PaqueteLectura.GeneradorAleatorio;
import PaqueteLectura.Lector;

/**
 *
 * @author Pedro master god
 */
public class EstanteriaDeLibros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GeneradorAleatorio.iniciar();
        Estanteria e = new Estanteria(5, 3);

        String titulo, nombre;
        double peso;
        Libro l;
        int estante, lugar;
        for (int i = 0; i < 100; i++) {
            titulo = GeneradorAleatorio.generarString(15);
            nombre = GeneradorAleatorio.generarString(15);
            peso = GeneradorAleatorio.generarDouble(500);
            l = new Libro(titulo, nombre, peso);

            estante = GeneradorAleatorio.generarInt(5);
            lugar = GeneradorAleatorio.generarInt(3);
            System.err.println("Estante: " + estante + ".");
            System.err.println("Lugar: " + lugar + ".");
            e.almacenarLibro(l, estante, lugar);
        }
        System.out.println(e.toString());
        System.out.println("Ingrese un titulo para sacar ese libro:");
        titulo = Lector.leerString();
        if (e.sacarLibro(titulo) != null) {
            System.out.println("Libro sacado: " + e.sacarLibro(titulo).toString());
        } else {
            System.out.println("El libro de titulo " + titulo + " no existe.");
        }
        System.out.println("Libro mas pesado: " + e.calcular().getTitulo());
    }
}
